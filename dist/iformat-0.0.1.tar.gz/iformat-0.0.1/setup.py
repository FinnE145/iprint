from setuptools import setup

setup(name="iprint",
      version="1.0",
      packages=["iprint"])